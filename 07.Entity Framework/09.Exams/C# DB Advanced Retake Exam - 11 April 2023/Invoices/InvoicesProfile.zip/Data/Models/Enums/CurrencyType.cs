﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Invoices.Data.Models.Enums
{
    public enum CurrencyType
    {
        BGN = 0, 
        EUR = 1, 
        USD = 2
    }
}
